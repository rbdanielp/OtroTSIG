package uy.tsig.grupo16.logica;

public class LogicaException extends Exception {


	private static final long serialVersionUID = 1L;

	public LogicaException(String mensaje) {
        super(mensaje);
    }

}
